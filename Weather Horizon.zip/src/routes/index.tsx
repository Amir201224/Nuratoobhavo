import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from "recharts";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Погода Нурота — 7 дней" },
      { name: "description", content: "Прогноз погоды для Нурота, Навоийская область, Узбекистан на неделю с интерактивным графиком." },
      { property: "og:title", content: "Погода Нурота — 7 дней" },
      { property: "og:description", content: "Прогноз погоды для Нурота на неделю." },
    ],
  }),
  component: Index,
});

const LAT = 40.5617;
const LON = 65.6892;

type Lang = "ru" | "uz" | "en" | "tg";

const LANGS: { code: Lang; label: string; flag: string }[] = [
  { code: "ru", label: "RU", flag: "🇷🇺" },
  { code: "uz", label: "UZ", flag: "🇺🇿" },
  { code: "en", label: "EN", flag: "🇬🇧" },
  { code: "tg", label: "TJ", flag: "🇹🇯" },
];

const T: Record<Lang, {
  location: string;
  region: string;
  loading: string;
  error: string;
  feels: string;
  humidity: string;
  wind: string;
  windUnit: string;
  chartTitle: string;
  forecastTitle: string;
  today: string;
  max: string;
  min: string;
  data: string;
  coords: string;
  locale: string;
}> = {
  ru: {
    location: "Нурота", region: "Навоийская область, Узбекистан",
    loading: "Загрузка погоды…", error: "Ошибка загрузки",
    feels: "Ощущается как", humidity: "Влажность", wind: "Ветер", windUnit: "км/ч",
    chartTitle: "Температура на 7 дней", forecastTitle: "Прогноз на неделю",
    today: "Сегодня", max: "Макс", min: "Мин",
    data: "Данные: Open-Meteo", coords: "Координаты", locale: "ru-RU",
  },
  uz: {
    location: "Nurota", region: "Navoiy viloyati, Oʻzbekiston",
    loading: "Ob-havo yuklanmoqda…", error: "Yuklashda xatolik",
    feels: "His qilinishi", humidity: "Namlik", wind: "Shamol", windUnit: "km/soat",
    chartTitle: "7 kunlik harorat", forecastTitle: "Haftalik prognoz",
    today: "Bugun", max: "Yuq", min: "Past",
    data: "Maʼlumot: Open-Meteo", coords: "Koordinatalar", locale: "uz-UZ",
  },
  en: {
    location: "Nurota", region: "Navoiy Region, Uzbekistan",
    loading: "Loading weather…", error: "Failed to load",
    feels: "Feels like", humidity: "Humidity", wind: "Wind", windUnit: "km/h",
    chartTitle: "7-day temperature", forecastTitle: "Weekly forecast",
    today: "Today", max: "High", min: "Low",
    data: "Data: Open-Meteo", coords: "Coordinates", locale: "en-GB",
  },
  tg: {
    location: "Нурота", region: "Вилояти Навоӣ, Ӯзбекистон",
    loading: "Боркунии обу ҳаво…", error: "Хатои боркунӣ",
    feels: "Эҳсос мешавад", humidity: "Намӣ", wind: "Шамол", windUnit: "км/соат",
    chartTitle: "Ҳарорат барои 7 рӯз", forecastTitle: "Пешгӯӣ барои ҳафта",
    today: "Имрӯз", max: "Макс", min: "Мин",
    data: "Маълумот: Open-Meteo", coords: "Координатҳо", locale: "tg-TJ",
  },
};

const WMO_I18N: Record<Lang, Record<number, string>> = {
  ru: {
    0:"Ясно",1:"В основном ясно",2:"Переменная облачность",3:"Пасмурно",45:"Туман",48:"Изморозь",
    51:"Морось",53:"Морось",55:"Сильная морось",61:"Дождь",63:"Дождь",65:"Сильный дождь",
    71:"Снег",73:"Снег",75:"Сильный снег",80:"Ливень",81:"Ливень",82:"Сильный ливень",
    95:"Гроза",96:"Гроза с градом",99:"Сильная гроза",
  },
  uz: {
    0:"Ochiq",1:"Asosan ochiq",2:"Oz bulutli",3:"Bulutli",45:"Tuman",48:"Qirov tuman",
    51:"Yengil yomgʻir",53:"Yomgʻir",55:"Kuchli yomgʻir",61:"Yomgʻir",63:"Yomgʻir",65:"Kuchli yomgʻir",
    71:"Qor",73:"Qor",75:"Kuchli qor",80:"Jala",81:"Jala",82:"Kuchli jala",
    95:"Momaqaldiroq",96:"Momaqaldiroq va doʻl",99:"Kuchli momaqaldiroq",
  },
  en: {
    0:"Clear",1:"Mostly clear",2:"Partly cloudy",3:"Overcast",45:"Fog",48:"Rime fog",
    51:"Drizzle",53:"Drizzle",55:"Heavy drizzle",61:"Rain",63:"Rain",65:"Heavy rain",
    71:"Snow",73:"Snow",75:"Heavy snow",80:"Showers",81:"Showers",82:"Heavy showers",
    95:"Thunderstorm",96:"Thunder with hail",99:"Severe thunder",
  },
  tg: {
    0:"Кушод",1:"Асосан кушод",2:"Каме абрнок",3:"Абрнок",45:"Туман",48:"Туман",
    51:"Боронак",53:"Боронак",55:"Боронаки сахт",61:"Борон",63:"Борон",65:"Борони сахт",
    71:"Барф",73:"Барф",75:"Барфи сахт",80:"Боронрезӣ",81:"Боронрезӣ",82:"Боронрезии сахт",
    95:"Раъду барқ",96:"Раъду барқ бо жола",99:"Раъду барқи сахт",
  },
};

type WeatherData = {
  current: {
    temperature_2m: number;
    apparent_temperature: number;
    relative_humidity_2m: number;
    wind_speed_10m: number;
    weather_code: number;
    is_day: number;
  };
  daily: {
    time: string[];
    weather_code: number[];
    temperature_2m_max: number[];
    temperature_2m_min: number[];
    precipitation_sum: number[];
    wind_speed_10m_max: number[];
  };
  hourly: {
    time: string[];
    temperature_2m: number[];
  };
};

const WMO_ICON: Record<number, string> = {
  0:"☀️",1:"🌤️",2:"⛅",3:"☁️",45:"🌫️",48:"🌫️",51:"🌦️",53:"🌦️",55:"🌧️",
  61:"🌧️",63:"🌧️",65:"🌧️",71:"🌨️",73:"🌨️",75:"❄️",80:"🌧️",81:"⛈️",82:"⛈️",
  95:"⛈️",96:"⛈️",99:"⛈️",
};

function wmo(code: number, lang: Lang) {
  return { label: WMO_I18N[lang][code] ?? "—", icon: WMO_ICON[code] ?? "🌡️" };
}

function dayName(iso: string, idx: number, lang: Lang) {
  if (idx === 0) return T[lang].today;
  const d = new Date(iso);
  return d.toLocaleDateString(T[lang].locale, { weekday: "short", day: "numeric", month: "short" });
}

function Index() {
  const [lang, setLang] = useState<Lang>("ru");
  const [data, setData] = useState<WeatherData | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const t = T[lang];

  useEffect(() => {
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${LAT}&longitude=${LON}&current=temperature_2m,apparent_temperature,relative_humidity_2m,wind_speed_10m,weather_code,is_day&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,wind_speed_10m_max&hourly=temperature_2m&forecast_days=7&timezone=auto`;
    fetch(url)
      .then((r) => r.json())
      .then(setData)
      .catch((e) => setErr(String(e)));
  }, []);

  const chartData =
    data?.daily.time.map((t, i) => ({
      day: new Date(t).toLocaleDateString(T[lang].locale, { weekday: "short" }),
      max: data.daily.temperature_2m_max[i],
      min: data.daily.temperature_2m_min[i],
    })) ?? [];

  const cur = data?.current;
  const curWmo = cur ? wmo(cur.weather_code, lang) : null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[oklch(0.22_0.08_255)] via-[oklch(0.18_0.06_250)] to-[oklch(0.15_0.05_240)] text-foreground">
      {/* Floating orbs */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute -top-40 -left-40 h-96 w-96 rounded-full bg-primary/20 blur-3xl animate-pulse" />
        <div className="absolute top-1/3 -right-40 h-[500px] w-[500px] rounded-full bg-[oklch(0.7_0.2_30)]/20 blur-3xl" />
      </div>

      <div className="relative mx-auto max-w-6xl px-6 py-12">
        <header className="mb-12 flex items-start justify-between gap-4">
          <div>
            <p className="text-sm uppercase tracking-[0.3em] text-primary/80">📍 {t.region}</p>
            <h1 className="mt-2 text-6xl font-bold tracking-tight md:text-7xl">{t.location}</h1>
          </div>
          <div className="flex gap-1 rounded-full border border-white/10 bg-white/[0.05] p-1 backdrop-blur-xl">
            {LANGS.map((l) => (
              <button
                key={l.code}
                onClick={() => setLang(l.code)}
                className={`rounded-full px-3 py-1.5 text-xs font-semibold transition-all ${
                  lang === l.code
                    ? "bg-primary text-primary-foreground shadow-lg"
                    : "text-foreground/70 hover:text-foreground"
                }`}
              >
                <span className="mr-1">{l.flag}</span>{l.label}
              </button>
            ))}
          </div>
        </header>

        {err && <p className="text-destructive">{t.error}: {err}</p>}
        {!data && !err && <p className="text-muted-foreground">{t.loading}</p>}

        {cur && curWmo && data && (
          <>
            {/* Current weather hero card */}
            <div
              className="relative mb-10 overflow-hidden rounded-3xl border border-white/10 p-8 md:p-12 shadow-2xl"
              style={{
                background:
                  "linear-gradient(135deg, oklch(0.35 0.15 240 / 0.6), oklch(0.25 0.1 260 / 0.4))",
                backdropFilter: "blur(20px)",
                transform: "perspective(1200px) rotateX(2deg)",
                boxShadow: "0 30px 80px -20px oklch(0.5 0.2 240 / 0.4)",
              }}
            >
              <div className="flex flex-col items-start justify-between gap-8 md:flex-row md:items-center">
                <div>
                  <div className="text-9xl drop-shadow-2xl md:text-[10rem]" style={{ filter: "drop-shadow(0 10px 30px oklch(0.7 0.2 240 / 0.5))" }}>
                    {curWmo.icon}
                  </div>
                </div>
                <div className="flex-1">
                  <div className="flex items-start gap-2">
                    <span className="text-8xl font-bold tracking-tighter md:text-9xl">
                      {Math.round(cur.temperature_2m)}
                    </span>
                    <span className="mt-4 text-4xl text-primary">°C</span>
                  </div>
                  <p className="mt-2 text-2xl text-foreground/80">{curWmo.label}</p>
                  <p className="text-sm text-muted-foreground">
                    {t.feels} {Math.round(cur.apparent_temperature)}°
                  </p>
                </div>
                <div className="grid grid-cols-2 gap-4 md:gap-6">
                  <Stat label={t.humidity} value={`${cur.relative_humidity_2m}%`} icon="💧" />
                  <Stat label={t.wind} value={`${Math.round(cur.wind_speed_10m)} ${t.windUnit}`} icon="💨" />
                </div>
              </div>
            </div>

            {/* 3D-feel chart */}
            <section className="mb-10 rounded-3xl border border-white/10 bg-white/[0.03] p-6 backdrop-blur-xl md:p-8">
              <h2 className="mb-6 text-2xl font-semibold">{t.chartTitle}</h2>
              <div className="h-72 w-full">
                <ResponsiveContainer>
                  <AreaChart data={chartData} margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
                    <defs>
                      <linearGradient id="hot" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="oklch(0.75 0.2 30)" stopOpacity={0.8} />
                        <stop offset="100%" stopColor="oklch(0.75 0.2 30)" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="cold" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="oklch(0.75 0.18 220)" stopOpacity={0.8} />
                        <stop offset="100%" stopColor="oklch(0.75 0.18 220)" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 0.08)" />
                    <XAxis dataKey="day" stroke="oklch(1 0 0 / 0.5)" />
                    <YAxis stroke="oklch(1 0 0 / 0.5)" unit="°" />
                    <Tooltip
                      contentStyle={{
                        background: "oklch(0.2 0.05 250 / 0.95)",
                        border: "1px solid oklch(1 0 0 / 0.1)",
                        borderRadius: 12,
                        color: "white",
                      }}
                      formatter={(v: number) => `${Math.round(v)}°`}
                    />
                    <Area type="monotone" dataKey="max" stroke="oklch(0.8 0.2 30)" strokeWidth={3} fill="url(#hot)" name={t.max} />
                    <Area type="monotone" dataKey="min" stroke="oklch(0.8 0.18 220)" strokeWidth={3} fill="url(#cold)" name={t.min} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </section>

            {/* 7-day forecast cards */}
            <section>
              <h2 className="mb-6 text-2xl font-semibold">{t.forecastTitle}</h2>
              <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7">
                {data.daily.time.map((dt, i) => {
                  const w = wmo(data.daily.weather_code[i], lang);
                  return (
                    <div
                      key={dt}
                      className="group relative overflow-hidden rounded-2xl border border-white/10 bg-white/[0.04] p-5 text-center backdrop-blur-xl transition-all hover:-translate-y-2 hover:bg-white/[0.08] hover:shadow-2xl"
                      style={{
                        boxShadow: "inset 0 1px 0 oklch(1 0 0 / 0.1), 0 10px 30px -10px oklch(0 0 0 / 0.5)",
                      }}
                    >
                      <p className="text-xs uppercase tracking-wider text-muted-foreground">
                        {dayName(dt, i, lang)}
                      </p>
                      <div className="my-3 text-5xl transition-transform group-hover:scale-110" style={{ filter: "drop-shadow(0 6px 12px oklch(0.7 0.15 240 / 0.4))" }}>
                        {w.icon}
                      </div>
                      <p className="text-xs text-foreground/70">{w.label}</p>
                      <div className="mt-3 flex items-center justify-center gap-2">
                        <span className="text-lg font-semibold text-[oklch(0.8_0.2_30)]">
                          {Math.round(data.daily.temperature_2m_max[i])}°
                        </span>
                        <span className="text-sm text-[oklch(0.75_0.18_220)]">
                          {Math.round(data.daily.temperature_2m_min[i])}°
                        </span>
                      </div>
                      {data.daily.precipitation_sum[i] > 0 && (
                        <p className="mt-2 text-xs text-primary">
                          💧 {data.daily.precipitation_sum[i]} мм
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
            </section>

            <footer className="mt-12 text-center text-xs text-muted-foreground">
              {t.data} · {t.coords} {LAT}, {LON}
            </footer>
          </>
        )}
      </div>
    </div>
  );
}

function Stat({ label, value, icon }: { label: string; value: string; icon: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.05] px-4 py-3 backdrop-blur-md">
      <p className="text-xs uppercase tracking-wider text-muted-foreground">
        {icon} {label}
      </p>
      <p className="mt-1 text-xl font-semibold">{value}</p>
    </div>
  );
}
